// script.js - Loading Screen with Spline 3D
document.addEventListener("DOMContentLoaded", function () {
  // Create loading screen elements
  const loadingScreen = document.createElement("div");
  loadingScreen.className = "loading-screen";

  const splineViewer = document.createElement("spline-viewer");
  splineViewer.className = "loading-spline";
  splineViewer.setAttribute(
    "url",
    "https://prod.spline.design/ixpQZNBJ3Y8YvKB4/scene.splinecode"
  );
  splineViewer.setAttribute("loading-anim-type", "none");

  const loadingText = document.createElement("div");
  loadingText.className = "loading-text";
  loadingText.textContent = "Loading Trackademic";

  // Add elements to DOM
  loadingScreen.appendChild(splineViewer);
  loadingScreen.appendChild(loadingText);
  document.body.prepend(loadingScreen);

  // Load Spline viewer module
  const splineScript = document.createElement("script");
  splineScript.type = "module";
  splineScript.src =
    "https://unpkg.com/@splinetool/viewer@1.9.82/build/spline-viewer.js";
  document.head.appendChild(splineScript);

  // Handle loading completion
  splineViewer.addEventListener("load", function () {
    setTimeout(function () {
      loadingScreen.style.opacity = "0";
      setTimeout(function () {
        loadingScreen.remove();
      }, 500);
    }, 1500); // Minimum display time
  });

  // Fallback in case loading fails
  setTimeout(function () {
    if (document.body.contains(loadingScreen)) {
      loadingScreen.style.opacity = "0";
      setTimeout(function () {
        loadingScreen.remove();
      }, 500);
    }
  }, 5000); // Maximum wait time
});
