let items = [];

// Fetch data from JSON file
fetch("../../asset/json/lostFound.json")
  .then((response) => response.json())
  .then((data) => {
    items = data;
    displayItems(items);
  })
  .catch((error) => console.error("Error loading JSON:", error));

function displayItems(itemsToDisplay) {
  const container = document.getElementById("itemsContainer");
  container.innerHTML = "";

  if (itemsToDisplay.length === 0) {
    document.getElementById("notFound").style.display = "block";
    return;
  } else {
    document.getElementById("notFound").style.display = "none";
  }

  itemsToDisplay.forEach((item) => {
    const itemCard = document.createElement("div");
    itemCard.className = "item-card";

    itemCard.innerHTML = `
            <div class="item-image">
                ${
                  item.image_url
                    ? `<img src="${item.image_url}" alt="${item.item_name}">`
                    : ""
                }
            </div>
            <div class="item-content">
                <div class="item-header">
                    <h3 class="item-name">${item.item_name}</h3>
                    <span class="item-status ${
                      item.status === "Found" ? "status-found" : "status-lost"
                    }">
                        ${item.status}
                    </span>
                </div>
                <div class="item-meta">
                    <div><strong>Category:</strong> ${item.category}</div>
                    <div><strong>Reported on:</strong> ${
                      item.date_reported
                    }</div>
                    <div><strong>Last seen:</strong> ${
                      item.location_last_seen
                    }</div>
                    <div><strong>Item ID:</strong> ${item.item_id}</div>
                </div>
                <p class="item-description">${item.description}</p>
                <div class="item-footer">
                    <div class="reporter-info">
                        <div><strong>Reported by:</strong> ${
                          item.reporter.name
                        }</div>
                        <div><strong>Student ID:</strong> ${
                          item.reporter.student_id
                        }</div>
                    </div>
                    <button class="contact-btn" onclick="contactReporter('${
                      item.reporter.contact.email
                    }', '${item.reporter.contact.phone}')">
                        Contact
                    </button>
                </div>
            </div>
        `;

    container.appendChild(itemCard);
  });
}

function searchItems() {
  const searchTerm = document.getElementById("searchInput").value.toLowerCase();

  if (!searchTerm) {
    displayItems(items);
    return;
  }

  const filteredItems = items.filter((item) => {
    return (
      item.item_name.toLowerCase().includes(searchTerm) ||
      item.reporter.name.toLowerCase().includes(searchTerm) ||
      item.description.toLowerCase().includes(searchTerm) ||
      item.category.toLowerCase().includes(searchTerm) ||
      item.location_last_seen.toLowerCase().includes(searchTerm) ||
      item.item_id.toLowerCase().includes(searchTerm)
    );
  });

  displayItems(filteredItems);
}

function contactReporter(email, phone) {
  alert(`Contact Information:\nEmail: ${email}\nPhone: ${phone}`);
}

// Allow searching by pressing Enter key
document
  .getElementById("searchInput")
  .addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      searchItems();
    }
  });

// Add onchange event to the search input field
document.getElementById("searchInput").addEventListener("input", function () {
  searchItems();
});
