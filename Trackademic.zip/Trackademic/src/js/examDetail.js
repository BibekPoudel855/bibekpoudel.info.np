function searchStudent() {
  const searchInput = document.getElementById("searchInput").value;

  fetch("../../asset/json/examDetail.json")
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to fetch student data");
      }
      return response.json();
    })
    .then((data) => {
      const studentData = data.find(
        (student) => student.studentDetails.id === searchInput
      );

      const notFound = document.getElementById("notFound");
      const studentProfile = document.getElementById("studentProfile");
      const examTable = document.getElementById("examTable");
      const examTableBody = examTable.querySelector("tbody");

      if (studentData) {
        // Hide error message
        notFound.style.display = "none";

        // Show student profile
        studentProfile.style.display = "block";
        const details = studentData.studentDetails;
        const courseDetails = studentData.studentCourseDetail;

        document.getElementById("profileImage").src = details.profileImage;
        document.getElementById("studentName").textContent = details.name;
        document.getElementById("studentId").textContent = details.id;
        document.getElementById("studentAge").textContent = details.age;
        document.getElementById("studentGender").textContent = details.gender;
        document.getElementById("studentCourse").textContent =
          courseDetails.course;
        document.getElementById("studentSemester").textContent =
          courseDetails.semester;
        document.getElementById("studentSection").textContent =
          courseDetails.section;
        document.getElementById("studentBatch").textContent =
          courseDetails.batch;

        // Populate exam table
        examTableBody.innerHTML = "";
        studentData.subjects.forEach((subject) => {
          const exam = subject.examDetails;
          const row = document.createElement("tr");
          row.innerHTML = `
                        <td>${subject.name}</td>
                        <td>${subject.moduleCode}</td>
                        <td>${exam.date}</td>
                        <td>${exam.time}</td>
                        <td>${exam.block}</td>
                        <td>${exam.room}</td>
                        <td>${exam.floor}</td>
                        <td>${exam.seatNumber}</td>
                        <td>${exam.allowedMaterials.join(", ")}</td>
                    `;
          examTableBody.appendChild(row);
        });

        // Show exam table
        examTable.style.display = "table";
      } else {
        // Use errorMSG function to show error message
        errorMSG("Student not found. Please check the ID and try again.");

        // Hide student profile and exam table
        studentProfile.style.display = "none";
        examTable.style.display = "none";
      }
    })
    .catch((error) => {
      console.error("Error fetching student data:", error);
      errorMSG("An error occurred while fetching student data.");
    });
}

// Error message function
function errorMSG(message) {
  Swal.fire({
    icon: "error",
    title: "Oops...",
    text: `${message}`,
    footer: '<a href="#">Why do I have this issue?</a>',
  });
}
